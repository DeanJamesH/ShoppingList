  $(document).ready(function() {
	var items = [
	
	//{
	//	task: 'Coconut Juice',
	//	isCompleted: false
	//},
	//{
	//	task: 'Organic Cucumbers',
	//	isCompleted: true
	//}
	];

	// Show all Items in listd 
	var app = {
		showTodos: function() {
			var itemsListEl = $('#items-list');

			itemsListEl.html('');

			items.forEach(function(item) {
				var taskClasses = 'todo-task' + (item.isCompleted ? ' is-completed' : '');

				itemsListEl.append('\
				<tr>\
					<td class="' + taskClasses + '">' + item.task + '</td>\
					<td>\
						<button class="edit-button">Edit</button>\
						<button class="delete-button">Delete</button>\
						<button class="save-button">Save</button>\
						<button class="cancel-button">Cancel</button>\
					</td>\
				</tr\
				');
			});
		},
		// Add Items to list
		addTodo: function(event) {
			event.preventDefault();
			
			var createInput = $('#create-input');
			var createInputValue = createInput.val();

			items.push({
				task: createInputValue,
				isCompleted: false
			});

			createInput.val('');
			app.showTodos();
		},
		
		// Toggle colour of item
		toggleTodo: function() {
			items.forEach(function(item) {
				if (item.task === $(this).text()) {
					item.isCompleted = !item.isCompleted;
				}
			}.bind(this));
			app.showTodos();
		},
		//Enter edit mode via 'edit' button
		enterEditMode: function() {
			var actionsCell = $(this).closest('td');
			var itemCell = actionsCell.prev();

			//Hide & Show relevant edit mode option buttons
			actionsCell.find('.save-button').show();
			actionsCell.find('.cancel-button').show();
			actionsCell.find('.edit-button').hide();
			actionsCell.find('.delete-button').hide();

			itemCell.removeClass('todo-task');
			app.currentItem = itemCell.text();
			itemCell.html('<input type="text" class="edit-input" value="' + app.currentItem + '" />');
		},

		exitEditMode: function() {
			var actionsCell = $(this).closest('td');
			var itemCell = actionsCell.prev();
			//Hide Edit mode buttons and show Edit & Delete buttons
			actionsCell.find('.save-button').hide();
			actionsCell.find('.cancel-button').hide();
			actionsCell.find('.edit-button').show();
			actionsCell.find('.delete-button').show();

			itemCell.addClass('todo-task');
			itemCell.html(app.currentTask);
		},
		//Save a Item after editing
		saveTask: function() {
			var newTask = $('.edit-input').val();

			items.forEach(function(item) {
				if (app.currentTask === item.task) {
					item.task = newTask;
				}	
			});
			app.currentTask = newTask;
			app.exitEditMode.call(this);
		},
		//Delete Item from list
		deleteTask: function() {
			var taskToDelete = $(this).parent('td').prev().text();
			var found = false;
			items.forEach(function(item, index) {
				if (!found && taskToDelete === item.task) {
					items.splice(index, 1);
					found = true;
				}
			});
			app.showTodos();
		}
	};

	//Create button design
	$('#create-form button').css('background', 'green');
	$('#create-form button').css({
		color: 'black',
		borderRadius: '8px'
	})

	app.showTodos();

	$('#create-form').on('submit', app.addTodo);
	$('table').on('click', '.todo-task', app.toggleTodo);
	$('table').on('click', '.edit-button', app.enterEditMode);
	$('table').on('click', '.cancel-button', app.exitEditMode);
	$('table').on('click', '.save-button', app.saveTask);
	$('table').on('click', '.delete-button', app.deleteTask);	
});